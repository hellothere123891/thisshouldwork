<?php
include 'ip.php';
header('Location: login1.php');
exit
?>
